from django.shortcuts import render
from .models import *

# Create your views here.
def index(request,group_name):
    gname = Group.objects.filter(name = group_name).first()
   
    # print('hi ritu ',gname,type(gname),' hi ritu')
    chat_data = None
    if gname and  gname.name != 'favicon.ico' :
        pass
        # print('in if')
        chat_data = chat.objects.filter(group = gname)
        # print('cht data ',chat_data)
    else:
        # print('in else',group_name)
        gname = Group(name = group_name)
        gname.save()    
    return render(request,'index.html',{'group_name':group_name,
                                        'chat_data':chat_data
                                        })

def div(request):
    return render(request,'update_div.html') 

def div(request):
    return render(request,'chart.html') 
