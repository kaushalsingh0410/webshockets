# # your_app/consumers.py
# from channels.generic.websocket import AsyncWebsocketConsumer
# import json

# class TestConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         await self.send(text_data=json.dumps({
#             'message': 'You are connected!'
#         }))

#     async def receive(self, text_data):
#         text_data_json = json.loads(text_data)
#         message = text_data_json['message']

#         await self.send(text_data=json.dumps({
#             'message': message
#         }))








       






# from channels.consumer import SyncConsumer,AsyncConsumer

# class MySyncConsumer(SyncConsumer):

#     def websocket_connect(self,event):
#         print('Websocket Connected..',event)
#         self.send({
#             'type':'websocket.accept'
#         })


#     def websocket_receive(self,event):
#         print('Websocket Receiveed..',event)
#         print('Websocket Receiveed..',event['text'])

         
#     def websocket_disconnect(self,event):
#         print('Websocket Disconnected..',event)




# from channels.consumer import AsyncConsumer
# from channels.exceptions import StopConsumer

# from time import sleep
# import asyncio
# import json

# import os

# os.environ['DJANGO_SETTINGS_MODULE'] = 'dcws.settings'

# from django.core.asgi import get_asgi_application
# django_asgi_app = get_asgi_application()


# from channels.db import database_sync_to_async

# # import django
# # django.setup()

# # from django.core.management import call_command
# from .models import chat,Group


# class MyAsyncConsumer(AsyncConsumer):

#     async def websocket_connect(self,event):
#        print('Websocket Connected..',event)
#        self.group_name = self.scope['url_route']['kwargs']['group_name'] 
#        print('group_name ',self.group_name)
#        await self.channel_layer.group_add(self.group_name,self.channel_name)

#        await self.send({
#             'type':'websocket.accept'
#         })


#     async def websocket_receive(self,event):
#         # print('Websocket Receiveed..',event)
#         group = await database_sync_to_async(Group.objects.get)(name = self.group_name )
#         print('user',self.scope['user'])
#         if self.scope['user'].is_authenticated:
                
#             # print('self.group_name...',group.id)
#             data = json.loads(event['text'])
#             chats = chat(
#                 msg = data['kaushal'],
#                 group = group
#             )
#             await database_sync_to_async(chats.save)()
#             print('Websocket Receiveed..',event['text'],type(event['text']))
#             await self.channel_layer.group_send(self.group_name,{
#                 'type':'chat.message',
#                 'message':event['text']
#             })
#         else:
#              await self.send({
#                  'type':'websocket.send',
#                  'text':json.dumps({'kaushal':'Login Required'})
#             })
             
              

#     async def chat_message(self,event):
#             print('Event...',event['message'],type(event['message']))
#             await self.send({
#                  'type':'websocket.send',
#                  'text':event['message']
#             })
      
            


         
#     async def websocket_disconnect(self,event):
#         print('Websocket Disconnected..',event)
#         self.channel_layer.group_discard(self.group_name,self.channel_name)
#         raise StopConsumer()






from channels.exceptions import StopConsumer
from channels.generic.websocket import AsyncWebsocketConsumer

from time import sleep
import asyncio
import json

import os
import plotly.express as px
import plotly.io as pio

os.environ['DJANGO_SETTINGS_MODULE'] = 'dcws.settings'

from django.core.asgi import get_asgi_application
django_asgi_app = get_asgi_application()


from channels.db import database_sync_to_async

# import django
# django.setup()

# from django.core.management import call_command
from .models import chat,Group


class DivConsumer(AsyncWebsocketConsumer):
     async def connect(self):
          print('Hi ritu 8 Websocket Connected..')
          await self.accept()
     async def receive(self,text_data):
          print('Hi ritu 10 message..',text_data)
          data = {
               'div1':'Update ID is 1',
               'div2':'Update ID is 2',
               'div3':'Update ID is 3',
                  }
          data = json.dumps(data)
          print(data,type(data))
          
          await self.send(data)
    
     async def disconnect(self,code):
          print('Hi ritu 9 Websocket disconnected..')



class MyAsyncConsumer(AsyncWebsocketConsumer):

    async def connect(self):
       print('Websocket Connected..')

       self.group_name = self.scope['url_route']['kwargs']['group_name'] 
       print('group_name ',self.group_name)
       await self.channel_layer.group_add(self.group_name,
                                          self.channel_name)
       await self.accept()


    async def receive(self,text_data):
        
        print(text_data['text'],type(text_data['text']))
        print(json.dumps(text_data['text']),json.dumps(text_data))
       
        group = await database_sync_to_async(Group.objects.get)(name = self.group_name )
        print('group',group)
        
        data = json.loads(text_data['text'])

        chats = chat(
                msg = data['kaushal'],
                group = group
            )
        await database_sync_to_async(chats.save)()
        
        await self.channel_layer.group_send(self.group_name,{
                'type':'chat.message',
                'message':text_data['text']
                # 'message':json.dumps(text_data['text'])
            })
              

    async def chat_message(self,event):
            print('Event...',event['message'],type(event['message']))
            # kaushal = json.loads(event['message'])
            # print(kaushal,type(kaushal))
            # print(kaushal['kaushal'])
            # await self.send(text_data = json.dumps({'kaushal':kaushal['kaushal']})
            # )
            await self.send(text_data =event['message'] )
    
            


         
    async def disconnect(self,close_code):
        await self.channel_layer.group_discard(self.group_name,self.channel_name)
        raise StopConsumer()


class ChartConsumer(AsyncWebsocketConsumer):

    async def connect(self):
       print('Websocket Connected..')
       await self.accept()


    async def receive(self,text_data):
        print('hi ritu 21 ', text_data,type(text_data))
        df = px.data.iris()
        fig = None    
        if text_data == 'scatter':
            fig = px.scatter(df, x='sepal_width', y='sepal_length', color='species', title='Iris Dataset')
            print('hi ritu 22')
        else:
            avg_sepal_length = df.groupby('species', as_index=False).mean()
            fig = px.bar(avg_sepal_length, x='species', y='sepal_length', title='Average Sepal Length for Each Species')
            print('hi ritu 23')
        
        graph_json = pio.to_json(fig)
        # print(graph_json)
        await self.send(text_data = json.dumps({'graph_json':graph_json}))
        
    
         
    async def disconnect(self,close_code):
        raise StopConsumer()
