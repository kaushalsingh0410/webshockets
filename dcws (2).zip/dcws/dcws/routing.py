# your_project/routing.py
from django.urls import path
from app.consumers import MyAsyncConsumer,DivConsumer,ChartConsumer

websocket_urlpatterns = [
    path("ws/ac/<str:group_name>/", MyAsyncConsumer.as_asgi()),
    path("ws/div/", DivConsumer.as_asgi()),
    path("ws/chart/", ChartConsumer.as_asgi()),
]
